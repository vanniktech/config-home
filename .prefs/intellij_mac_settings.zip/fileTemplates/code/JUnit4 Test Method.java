@org.junit.Test public void ${NAME}() {
  ${BODY}
}